from cryptography.fernet import Fernet
from os import system

#cf = Fernet.generate_key()
#print(cf)
#print(f'clave de acceso: {cf.decode()}')

clave_fernet = "-cR7-mYvYL6m1YhQGDDZK8awdPFkfUKXuvo64pPkvls="    #aqui esta la "llave" para la encriptacion y la desencriptacion
cont = input('contra?: ')

f= Fernet(clave_fernet)                                          #se usa la funcion Fernet() con clave_fernet como base para hacer la encriptación
#f2 = Fernet()                                                   TypeError: Fernet.__init__() missing 1 required positional argument: 'key'

cont_encr = f.encrypt(cont.encode())                             #el .encode() le da un "plus" de encriptacion, .decode() quita la encriptacion
print(cont.encode())
print(cont_encr)
print(f'contraseña encriptada: {cont_encr.decode()}')
print(f'longitud: {len(cont_encr)}', end="\n\n")

cont_descry = f.decrypt(cont_encr)
cont_descr = f.decrypt(cont_encr).decode()                       #usar f.encrypt hace que Fernet(clave_fernet) funcione, generando que los que sea que metiste en cont sea encriptado en base a clave_fernet---   --- usar f.decrypt hace lo contrario en base al Fernet(clave_fernet)
print(cont_descr)
print(cont_descry)
print(f'longitud: {len(cont_descr)}', end="\n\n")

aa = input('')
bb= f.decrypt(aa).decode()   
print(bb)