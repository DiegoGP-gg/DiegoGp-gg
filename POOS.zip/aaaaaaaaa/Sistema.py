#__________________________________________CLASES
from empleados import Empleados
from departamentos import Departamentos
from Persona import Persona
from Usuarios import Usuario

#__________________________________________DAOS
from DAO import dao
from DAO_dep import daoDep
from DAO_login import DaoLog

#__________________________________________HERRAMIENTAS EXTRAS
from cryptography.fernet import Fernet
from beautifultable import BeautifulTable
from datetime import date
from os import system
import os
import re

#__________________________________________emine
from emine import eminem
from emine import fu


class sistema:
    dao = dao()
    daod = daoDep()
    daol = DaoLog()
    
    #______________________________________________________________INICIO DE SESIÓN
    def Menuini(self):
        while True:
            system('cls')
            print('INICIO DE SESIÓN\n\n.♥/(,")\.(".)♥★\n..★/♥\♥/█\♥★\n.♥_| |__| |_ ♥\n\n')
            try:
                op= int(input('Elige una opción \n1. Iniciar Sesión\n2. Olvidaste tu contraseña?\n3. Salir\n-'))
                if op == 1:
                    self.__InicioSesion()
                elif op == 2:
                    self.__RecupContra()
                elif op == 3:
                    self.__Salir()
                else:
                    print('Error-\nTienes que elegir una opción de las indicadas')
                    system('pause')
            except Exception as e:
                print(f'{fu()} {e}')
                system('pause')
    
    #______________________________________________________________MENU PRINCIPAL
    def MenuAdmin(self):
        while True:
            try:
                system('cls')
                print(' /)_/)\n(,,>.<)  <(MENU admin ALV)\n />❤️')
                op = int(input('Seleccione una opción:\n1.- Menú de Empleados\n2.- Menú de Departamentos\n3.- Cerrar Sesión\n\n-'))
                if op == 1:
                    self.__MenuEmpA()
                elif op == 2:
                    self.__MenuDepA()
                elif op == 3:
                    self.__CerrarSesion()
                else:
                    print(f'{eminem()} \nEri wn?')
                    system("pause")
            except:
                print(f'{fu()} \nEXCEPT menu')
                system('pause')
    
    def MenuDemas(self):
        while True:
            try:
                system('cls')
                print(' /)_/)\n(,,>.<)  <(MENU demas ALV)\n />❤️')
                op = int(input('Seleccione una opción:\n1.- Menú de Empleados\n2.- Menú de Departamentos\n3.- Cerrar Sesión\n\n-'))
                if op == 1:
                    self.__MenuEmpD()
                elif op == 2:
                    self.__MenuDepD()
                elif op == 3:
                    self.__CerrarSesion()
                else:
                    print(f'{eminem()} \nEri wn?')
                    system("pause")
            except:
                print(f'{fu()} \nEXCEPT menu')
                system('pause')
    #______________________________________________________________MENU EMPLEADOS
    
    def __MenuEmpA(self):
        while True:
            try:
                system('cls')
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Empleados A]')
                op = int(input('Seleccione una opción:\n1.- Crear Persona y Empleado\n2.- Listar Empleados\n3.- Buscar Empleado\n4.- Modificar Empleado\n5.- Eliminar Empleado\n6.- Estadisticas de Empleados\n7.- Salir\n\n-'))
                if op == 1:
                    self.__CrearEmp()
                elif op == 2:
                    self.__ListarEmp()
                elif op == 3:
                    self.__BuscarEmp()
                elif op == 4:
                    self.__ModificarEmp()
                elif op == 5:
                    self.__EliminarEmp()
                elif op == 6:
                    self.__EstadisticasEmp()
                elif op == 7:
                    self.MenuAdmin()
                else:
                    print(f'{eminem()} \nEri wn?')
                    system('pause')
            except ValueError:
                print(f'{fu()} except menu empleados')
                system('pause')
    
    def __MenuEmpD(self):
        while True:
            try:
                system('cls')
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Empleados D]')
                op = int(input('Seleccione una opción:\n1.- Listar Empleados\n2.- Buscar Empleado\n3.- Estadisticas de Empleados\n4.- Salir\n\n-'))
                if op == 1:
                    self.__ListarEmp()
                elif op == 2:
                    self.__BuscarEmp()
                elif op == 3:
                    self.__EstadisticasEmp()
                elif op == 4:
                    self.MenuDemas()
                else:
                    print(f'{eminem()} \nEri wn?')
                    system('pause')
            except ValueError:
                print(f'{fu()} except menu empleados')
                system('pause')
    #______________________________________________________________MENU DEPARTAMENTOS
    
    def __MenuDepA(self):
        while True:
            try:
                system('cls')
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Departamentos A]')
                op = int(input('Seleccione una opción:\n1.- Crear Departamento\n2.- Listar Departamentos\n3.- Buscar Departamento\n4.- Modificar Departamento\n5.- Eliminar Departamento\n6.- Estadisticas de Departamentos\n7.- Salir\n\n-'))
                if op == 1:
                    self.__CrearDep()
                elif op == 2:
                    self.__ListarDep()
                elif op == 3:
                    self.__BuscarDep()
                elif op == 4:
                    self.__modificar_departamento()
                elif op == 5:
                    self.__EliminarDep()
                elif op == 6:
                    self.__EstadisticasDep()
                elif op == 7:
                    self.MenuAdmin()
                else:
                    print(f'{eminem()} \nEri wn?')
                    system('pause')
            except ValueError:
                print(f'{fu()} except menu departamentos')
                system('pause')
    
    def __MenuDepD(self):
        while True:
            try:
                system('cls')
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Departamentos D]')
                op = int(input('Seleccione una opción:\n1.- Listar Departamentos\n2.- Buscar Departamento\n3.- Estadisticas de Departamentos\n4.- Salir\n\n-'))
                if op == 1:
                    self.__ListarDep()
                elif op == 2:
                    self.__BuscarDep()
                elif op == 3:
                    self.__EstadisticasDep()
                elif op == 4:
                    self.MenuDemas()
                else:
                    print(f'{eminem()} \nEri wn?')
                    system('pause')
            except ValueError:
                print(f'{fu()} except menu departamentos')
                system('pause')
    #______________________________________________________________INICIO DE SESIÓN parte 2
    
    def __InicioSesion(self):
        while True:
            system('cls')
            print('INICIO DE SESIÓN\n\n.♥/(,")\.(".)♥★\n..★/♥\♥/█\♥★\n.♥_| |__| |_ ♥\n')
            usu= input('Introduce el nombre de Usuario:\n-')
            cont= input('Introduce la contraseña:\n-')
            try:
                if len(usu) == 0:
                    print(f'{eminem()}\nEri wn')
                    print('aaaaaaaaaaaaaaaaaaaa')
                    system('pause')
                    self.Menuini()
                else:
                    rs= self.daol.comprobarUsuario(usu)
                    cf = "-cR7-mYvYL6m1YhQGDDZK8awdPFkfUKXuvo64pPkvls="
                    f= Fernet(cf)
                    rs1= f.decrypt(rs[0]).decode()
                    rs2= rs[1]
                    rs3= rs[2]
                    if rs1 == cont:
                        if rs2 == 1:
                            if rs3 == 1:
                                print('wena xuxetumare pro (yendo al menu admin)')
                                system('pause')
                                self.MenuAdmin()
                            elif rs3 == 2:
                                print('wena wekito (yendo al menu demas)')
                                system('pause')
                                self.MenuDemas()
                        elif rs2 == 2:
                            print('manito, que haces aqui, fuiste despedido hace tiempo ya')
                            system('pause')
                            self.Menuini()
                    else:
                        print(f'{fu()}\nManito te equivocaste de contraseña pa')
                        system('pause')
            except Exception as e:
                print(f'{fu()}\n{e}\nHey por aqui (except __iniciosesion )')
                system('pause')
    
    def __RecupContra(self):
        fe= None
        while True:
            system('cls')
            print('CAMBIAR CONTRASEÑA AAAAAAAAA\n\n.♥/(,")\.(".)♥★\n..★/♥\♥/█\♥★\n.♥_| |__| |_ ♥\n')
            cor= input('Introduce el correo del Usuario:\n-')
            try:
                if len(cor) == 0:
                    print(f'{eminem()}\nEri wn')
                    system('pause')
                    self.Menuini()
                else:
                    rs= self.daol.recuperarContra(cor)
                    if rs is None:
                        print(f'{fu()}te equivocaste manito o no existe, una de dos\n')
                        system('pause')
                        self.Menuini()
                    else:
                        aa = rs[5]
                        if aa == 1:
                            print('Si existe manito\n')
                            con= input('ahora mi loco necesito que hagas otra contraseña\nen lo posible que sea de minimo y maximo 4 caracteres\n\n-')
                            if len(con) == 4:
                                cor = rs[3]
                                cf = "-cR7-mYvYL6m1YhQGDDZK8awdPFkfUKXuvo64pPkvls="
                                fe = Fernet(cf)
                                conN= fe.encrypt(con.encode())
                                self.daol.cambiarContra(cor, conN)
                                print('ya manito, se hizo el cambio qlo')
                                system('pause')
                                self.Menuini()
                            else:
                                print(f'{eminem()}\neriwn')
                                system('pause')
                        else:
                            print('que chucha mano, tu estas despedido hace rato, que haces aqui?')
                            system('pause')
                            self.Menuini()
            except Exception as e:
                print(f'{fu()}\n{e}\nHey por aqui RecupContra')
                system('pause')
                self.Menuini()
    
    def __CerrarSesion(self):
        print('Cerrando Sesión...\n\n')
        system('pause')
        self.Menuini()
    #______________________________________________________________FUNCIONES EMPLEADOS
    
    ##_____________________________CREAR EMPLEADOS Y PERSONAS
    
    def __CrearEmp(self):
        pe = Persona()
        em = Empleados()
        
        while True:
            try:
                rut = int(input("Digite El Rut Del Nuevo Empleado\n-"))
                if 1<= len(str(abs(rut))) <=20:
                    break
                else:
                    print("\n--- Debe Tener Entre 1 y 20 Caracteres!! ---")
                    system('pause')
            except:
                print(f'{fu()} except rut')
                system('pause')
        while True:
            try:
                nomp = (input("Digite El Nombre Del Nuevo Empleado (1-20)\n-"))
                if len(nomp.strip())>1 and len(nomp.strip())<20:
                    break
                else:
                    print("\n--- Debe Tener Entre 1 y 20 Caracteres!! nomp---")
                    system('pause')
            except:
                print(f'{fu()} except nomp')
                system('pause')
        while True:
            try:
                apep = (input("Digite el Apellido Paterno Del Nuevo Empleado (1-20)\n-"))
                if len(apep.strip())>1 and len(apep.strip())<20:
                    break
                else:
                    print("\n--- Debe Tener Entre 1 y 20 Caracteres!! apep---")
                    system('pause')
            except:
                print(f'{fu()} except apep')
                system('pause')
        while True:
            try:
                apem = (input("Digite el Apellido Materno Del Nuevo Empleado (1-20)\n-"))
                if len(apem.strip())>1 and len(apem.strip())<20:
                    break
                else:
                    print("\n--- Debe Tener Entre 1 y 20 Caracteres!! apem---")
                    system('pause')
            except:
                print(f'{fu()} except apem')
                system('pause')
        while True:
            try:
                dir = str(input("Digite la Dirección de calle Del Nuevo Empleado (10-30)\n-"))
                if 10<= len(dir.strip()) <=30:
                    break
                else:
                    print("\n--- Debe Tener Entre 10 y 30 Caracteres!! dir---")
                    system('pause')
            except:
                print(f'{fu()} except dir')
                system('pause')
        while True:
            try:
                Nte = int(input("Digite el Numero Del Nuevo Empleado (8-12)\n-"))
                if 8<= len(str(abs(Nte))) <=12:
                    break
                else:
                    print("\n--- Debe Tener Entre 8 y 12 Caracteres!! ---")
                    system('pause')
            except:
                print(f'{fu()} except Nte')
                system('pause')
        
        while True:
            try:
                deps = self.daod.listar_departamentos()
                self.daod.imprimir_departamentos(deps)
                ids_validos = {d.getIdDep() for d in deps}
                id_dept_select = str(input("Seleccione el departamento a asignar para el empleado nuevo\n- "))
                if id_dept_select.strip().isdigit() and int(id_dept_select) in ids_validos:
                    break
                else:
                    print("\n--- Debe seleccionar un departamento correcto ---")
                    system('pause')
            except Exception as e:
                print(f'Hubo un error al asignar el departamento \n{e}')
                system('pause')
        while True:
            fcon_raw = input("Digite la Fecha de entrada del nuevo empleado (dd-MM-YYYY)\n- ").strip()
            m = re.fullmatch(r'(\d{1,2})-(\d{1,2})-(\d{4})', fcon_raw)
            if not m:
                print("\n--- Formato inválido. Use dd-MM-YYYY, p. ej. 25-07-2025 ---")
                system('pause')
                continue
            d, mth, y = map(int, m.groups())
            try:
                dt = date(y, mth, d)
            except ValueError as e:
                print(f"\n--- Fecha inválida: {e} ---")
                system('pause')
                continue
            fcon = dt.strftime('%Y-%m-%d')
            break
        
        while True:
            try:
                sal = int(input("Digite el Salario Del Nuevo Empleado (100000 - 1200000)\n-"))
                if 100000<= sal <=1200000:
                    break
                else:
                    print("\n--- Debe Tener Entre 100000 y 1200000 Caracteres!! ---")
                    system('pause')
            except:
                print(f'{fu()}\n except sal')
                system('pause')
        
        try:
            pe.setRut(rut)
            pe.setNombre(nomp.title())
            pe.setApellidoP(apep.title())
            pe.setApellidoM(apem.title())
            pe.setDireccion(dir.title())
            pe.setNroTelefono(Nte)
            new_id = self.dao.crearPersona(pe)
        except Exception as e:
            print(e)
            system('pause')
        
        try:
            em.setFechaContrato(fcon)
            em.setSalario(sal)
            em.setIdDep(id_dept_select)
            em.setIdPer(new_id)
            em.setIdEst(1)
            self.dao.crearEmpleado(em)
        except Exception as e:
            print(e)
            system('pause')
        
        print(f"--- Nuevo Empleado { nomp } Creado Correctamente!!---\n\n yeih\n\n",)
        system("pause")
        self.__MenuEmpA()
    
    ##_____________________________LISTAR EMPLEADOS
    
    def __ListarEmp(self):
        system('cls')
        print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Empleados]')
        rs = self.dao.obtenerNombresEmp()
        if len(rs) == 0:
            system('cls')
            print('Tai seguro que hay?')
            system('pause')
            return
        else:
            system('cls')
            print('Listado de Empleados')
            aa = 1
            for x in rs:
                print(f'-----Empleado numero :{aa}-----')
                print(f'ID                 : {x[0]}')
                print(f'Rut                ; {x[1]}')
                print(f'Nombre             : {x[2]}')
                print(f'Apellido Paterno   : {x[3]}')
                print(f'Apellido Materno   : {x[4]}')
                print(f'Dirección          : {x[5]}')
                print(f'Telefono           : {x[6]}')
                print(f'Fecha de Contrato  : {x[7]}')
                print(f'Salario            : {x[8]}')
                print(f'Estado             : {x[9]}')
                print(f'Departamento       : {x[10]}\n')
                aa += 1
            system('pause')
            return
    
    ##_____________________________BUSCAR EMPLEADOS
    
    def __BuscarEmp(self):
        try:
            system('cls')
            print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Empleados]')
            nom = str(input('Introdusca el nombre del empleado\n\n-'))
            rs = self.dao.comprobarNombreEmp(nom)
            if rs is None:
                print('Tai seguro que se llama así?')
                system('pause')
                return
            else:
                print('Empleado encontrado -- yei')
                print(f"ID             : { rs[0] }")
                print(f"NOMBRE         : { rs[1] }")
                print(f"Apellido       : { rs[2] }")
                print(f"Fecha Contrato : { rs[3] }")
                print(f"Salario        : { rs[4] }")
                print(f"Estado         : { rs[5] }")
                print(f"Departamento   : { rs[6] }")
                system('pause')
                return
        except Exception as e:
            print(f'{fu()}\nerror buscaremp\n')
            print(e)
            system('pause')
            return
    
    ##_____________________________MODIFICAR EMPLEADOS
    
    def __ModificarEmp(self):
        while True:
            try:
                system('cls')
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Empleados]')
                aa = self.dao.obtenerNombresEmp2()
                table = BeautifulTable()
                table.column_headers = [ "ID","Nombre","Apellido","Salario","Estado" ]
                for x in aa:
                    table.rows.append([x[0], x[1], x[2], x[3], x[4]])
                system('cls')
                print(table,'\n')
                id= int(input('Introduce el ID del empleado\n\n-'))
                dato= int(input('Que le quieres modificar?\n1.Salario\n2.Habilitar trabajador deshabilitado\n\n-'))
                if id is None:
                    print('NO EXISTE ES ID AAAAAAAAAAAAAAAA')
                    system('pause')
                    return
                else:
                    if dato == 1:
                        try:
                            nuevo = int(input('Introduce nuevo salario (100000 - 1200000)\n\n-'))
                            if 100000<= nuevo <=1200000:
                                self.dao.actualizarEmpleado(dato, nuevo, id)
                                break
                            else:
                                print('\nEl salario debe estar en los parametros establecidos (100000 - 1200000)')
                                system('pause')
                        except Exception as e:
                            print(e, '\nerror if dato==1')
                    elif dato == 2:
                        est_actual = self.dao.obtenerEstadoEmpleado(id)
                        if est_actual is None:
                            print("\nEmpleado no encontrado")
                            system('pause')
                            continue
                        if est_actual == 1:
                            print('El trabajador ya está habilitado para trabajar')
                            system('pause')
                            return
                        elif est_actual == 2:
                            nuevo = 1
                        else:
                            print(f"Estado actual inválido ({est_actual}). Asegúrate de que exista en tabla estado.")
                            system('pause')
                            continue
                        self.dao.actualizarEmpleado(2, nuevo, id)
                        break
            except Exception as e:
                print(e)
                system('pause')
        try:
            print('Cambio del dato del empleado - check it')
            bb= self.dao.comprobarDatosEmp(id)
            print(f"ID             : {bb[0] }")
            print(f"NOMBRE         : {bb[1] }")
            print(f"Apellido       : {bb[2] }")
            print(f"Salario        : {bb[3] }")
            print(f"Estado         : {bb[4] }")
            system('pause')
        except Exception as e:
            print(f'{fu()}\n{e}')
            system('pause')
        return
    
    ##_____________________________ELIMINAR EMPLEADOS 
    
    def __EliminarEmp(self):
        try:
            aa = self.dao.listarNombresEmp()
            table = BeautifulTable()
            table.column_headers = [ "ID","Nombre","Apellido","Estado" ]
            for x in aa:
                table.rows.append([x[0], x[1], x[2], x[3]])
            system('cls')
            print(table)
            op = int(input('Digite el Id del empleado que quiera eliminar\n\n-'))
            if op is None:
                print('no existe\n\n')
                system('pause')
                return
            else:
                self.dao.eliminarEmpleado(op) 
                print('\nEl empleado ha sido eliminado exitosamente\n')
                rs = self.dao.comprobarEstadoEmp(op)
                print(f"ID             : {rs[0] }")
                print(f"NOMBRE         : {rs[1] }")
                print(f"Apellido       : {rs[2] }")
                print(f"Estado         : {rs[3] }")
                system('pause')
        except Exception as e:
                print(e)
                system('pause')
                return
    
    ##_____________________________ESTADISTICAS EMPLEADOS
    
    def __EstadisticasEmp(self):
        try:
            rs2 = self.dao.estadisticasNombresEmp()
            rs  = self.dao.estadisticasEmpHabilitados()
            if len(rs)==0 and len(rs2)==0:
                system("cls")
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Empleados]')
                print("\n\n====NO EXISTEN DATOS PO REY====\n\n")
                system("pause")
                return
            else:
                system("cls")
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Estadisticas de Empleados]\n')
                print(f"Cantidad de Empleados    : {rs2[0]}")
                print(f'Empleados Habilitados    : {rs [0]}\n')
                print(f'Promedio de Todos los Salarios          : {rs2[1]}')
                print(f'Promedio de los Salarios Habilitados    : {rs[1]}\n')
                print(f'Suma de Todos los Salarios                  : {rs2[2]}')
                print(f'Suma de Salario de Empleados Habilitados    : {rs2[2]}')
                system("pause")
                return
        except Exception as e:
            print(fu(), e)
            system('pause')
            return
    
    #______________________________________________________________FUNCIONES DEPARTAMENTOS
    
    ##_____________________________CREAR DEPARTAMENTO 
    
    def __CrearDep(self):
        de = Departamentos()
        try:
            system('cls')
            print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Departamentos]\n')
            nomd = str(input('Digite el nombre del nuevo departamento\n\n-'))
            aa = self.daod.comprobarNombresDep(nomd)
            print(aa)
            system('pause')
            if aa is not None:
                print(fu(), '\nya existe po manito')
                system('pause')
                self.__MenuDepA()
            else:
                while True:
                    try:
                        fman_raw = input('Cual es la fecha de mando? (dd-mm-yyyy))\n\n-').strip()
                        m = re.fullmatch(r'(\d{1,2})-(\d{1,2})-(\d{4})', fman_raw)
                        if not m:
                            print("\n--- Formato inválido. Use dd-MM-YYYY, p. ej. 25-07-2025 ---")
                            system('pause')
                            continue
                        d, mth, y = map(int, m.groups())
                        try:
                            dt = date(y, mth, d) #date() obtener una fecha con los valores de (y mth d)  
                        except ValueError as e:
                            print(f"\n--- Fecha inválida: {e} ---")
                            system('pause')
                            continue
                        fman = dt.strftime('%Y-%m-%d')
                        break
                    except Exception as e:
                        print(fu(), e)
                        system('pause')
        except Exception as e:
            print(fu(), e)
            system('pause')
        
        try:
            de.setNombreDep(nomd)
            de.setFechaMando(fman)
            self.daod.crearDepartamento(de)
            print('El departamento ha sido creado exitosamente')
            system('pause')
            self.__MenuDepA()
        except Exception as e:
            print(fu(), e)
            system('pause')
        
        print('El departamento ha sido creado exitosamente')
        system('pause')
        self.__MenuDepA()
    
    ##_____________________________LISTAR DEPARTAMENTO
    
    def __ListarDep(self):
        deps = self.daod.listar_departamentos()
        self.daod.imprimir_departamentos(deps)
        system('pause')
    
    ##_____________________________BUSCAR DEPARTAMENTO
    
    def __BuscarDep(self):
        while True:
            try:
                system('cls')
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Buscar Departamentos]')
                op = int(input('''Seleccione una opción:\n1.- Por ID\n2.- Por Nombre\n3.- Salir\n\n-'''))
                if op == 1:
                    self.__BuscarDepId()
                elif op == 2:
                    self.__BuscarDepNombre()
                elif op == 3:
                    return
                else:
                    print(f'{eminem()}eriwn')
            except:
                print(f'{fu()} \nEXCEPT menu')
                system('pause')
    
    def __BuscarDepId(self):
        try:
            system("cls")
            print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Menu Departamentos]')
            id = int(input("Digite El ID del Departamento a Buscar: "))
            aa = self.daod.buscarDepExistente(id)
            if aa is None:
                print(f"\n--- Error. El ID { id } No Existe!! ---\n\n")
                system("pause")
                self.__BuscarDep()
            else:
                print("\n--- Departamento encontrado ---")
                print(f"ID          : { aa[0] }")
                print(f"Nombre      : { aa[1].capitalize() }")
                print(f"Fecha Mando : { aa[2] }")
                print(f"Estado      : { aa[3].capitalize() }\n\n")
                system("pause")
                self.__BuscarDep()
        except Exception as e:
            print(f"{fu()}\n--- Error Al Intentar Buscar Editorial!! ---\n{e}\n")
            system("pause")
            self.__BuscarDep()
    
    def __BuscarDepNombre(self):
        try:
            while True:
                system('cls')
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Buscar Departamentos]')
                texto = str(input('Buscar departamento por nombre (enter = todos)\n\n-')).strip()
                deps = self.daod.buscar_por_nombre_y_listar_departamentos(texto)
                if not deps:
                    print('\n--- No hay coincidencias ---')
                    system('pause')
                while True:
                    opt = str(input('\n¿Desea realizar otra búsqueda?\n1) Sí\n2) No\n- ')).strip()
                    if opt == '1':
                        break
                    elif opt == '2':
                        system('pause')
                        self.__BuscarDep()
                        return
                    else:
                        print('\n--- Opción inválida ---')
                        system('pause')
        except Exception as e:
            print(f'{fu()}\nerror buscaremp\n{e}')
            system('pause')
            self.__BuscarDep()
    
    ##_____________________________MODIFICAR DEPARTAMENTO
    
    def __modificar_departamento(self):
        while True:
            try:
#__________________________________________________________________________________________________________________________________________________1) Lista departamentos
                deps = self.daod.listar_departamentos()
                self.daod.imprimir_departamentos(deps)
                ids_validos = {d.getIdDep() for d in deps}
#__________________________________________________________________________________________________________________________________________________2) Elegir departamento por ID
                while True:
                    try:
                        id_in = str(input("\nSeleccione el ID del departamento a modificar:\n(Escriba \"q\" o \"salir\" para cancelar)\n- ")).strip()
                        if id_in.lower() in {"q", "salir"}:
                            print("Operación cancelada.")
                            system("pause")
                            return
                        elif id_in.isdigit() and int(id_in) in ids_validos:
                            id_dep = int(id_in)
                            break
                        else:
                            print(f'{eminem()} \nEri wn?')
                            system("pause")
                    except Exception:
                        print(f"{fu()}\n--- Error leyendo el ID ---")
                        system("pause")
#__________________________________________________________________________________________________________________________________________________3) Listar columnas editables
                cols = self.daod.imprimir_columnas_editables()
                n = len(cols)
#__________________________________________________________________________________________________________________________________________________4) Elegir índices "1,3" o 0 para cancelar y volver a elegir departamento
                while True:
                    try:
                        idx_str = str(input("\nIngrese uno o varios índices, separados por coma (ej: 1,3), o ingrese 0 para cancelar:\n- ")).strip()
                        if idx_str == "0":
                            print("\nCancelado. Volviendo a elegir departamento...")
                            system("pause")
                            break
                        partes = [p.strip() for p in idx_str.split(",") if p.strip() != ""]
                        if not partes:
                            print(f'{eminem()} \nEri wn?')
                            system("pause")
                            continue
                        idxs = []
                        ok = True
                        for p in partes:
                            if p.isdigit():
                                v = int(p)
                                if 1 <= v <= n:
                                    idxs.append(v)
                                else:
                                    ok = False
                                    break
                            else:
                                ok = False
                                break
                        if not ok:
                            print(f"{fu()}\n--- Algún índice no existe. Intente de nuevo. ---")
                            system("pause")
                            continue

#__________________________________________________________________________________________________________________________________________________Quitar duplicados conservando orden
                        vistos = set()
                        idxs_unicos = []
                        for v in idxs:
                            if v not in vistos:
                                vistos.add(v)
                                idxs_unicos.append(v)

#__________________________________________________________________________________________________________________________________________________5) Pedir valores por cada columna seleccionada (en orden)
                        actual = self.daod.obtener_departamento_por_id(id_dep) or {}
                        cambios = {}
                        for v in idxs_unicos:
                            col = cols[v - 1]
                            actual_val = actual.get(col, "")
                            print(f"(Actual: {actual_val})")
                            while True:
                                try:
                                    val_mas_info = self.daod.mostrar_mas_info_valor_columna(col)
                                    val_in = str(input(f"Ingrese nuevo valor para '{col}':\n- "))
                                    ok_val, res = self.daod.validar_valor_columna(col, val_in, val_mas_info)
                                    if ok_val:
                                        cambios[col] = res
                                        break
                                    else:
                                        print(f"\n--- {res} ---")
                                        system("pause")
                                except Exception:
                                    print(f"\{fu()}n--- Error leyendo el valor ---")
                                    system("pause")

#__________________________________________________________________________________________________________________________________________________6) Ejecutar update parcial
                        if cambios:
                            afectadas = self.daod.update_departamento_parcial(id_dep, cambios)
                            if afectadas > 0:
                                print(f"\nCambios aplicados al departamento ID {id_dep}.")
                            else:
                                print(f"{fu()}\nNo se aplicaron cambios.")
                            system("pause")
                        else:
                            print(f"{fu()}\n(No seleccionaste columnas).")
                            system("pause")

#__________________________________________________________________________________________________________________________________________________Al terminar, decidir si resgresar al menú o repetir el flujo
                        opt = str(input("\n¿Modificar otro departamento?\n1) Sí\n2) No\n- ")).strip()
                        if opt == "1":
                            break
                        else:
                            self.__MenuDepA()
                            return
                    except Exception:
                        print(f"{fu()}\n--- Error procesando los índices ---")
                        system("pause")
                        continue
            except Exception as e:
                print(f"{fu()}\n--- Error general en modificar_departamento ---\n", e)
                system("pause")
                self.__MenuDepA()
                return
    
    ##_____________________________ELIMINAR EMPLEADOS 
    
    def __EliminarDep(self):
        try:
            deps = self.daod.listarDepDel()
            self.daod.imprimir_DepDel(deps)
            id = int(input('Digite el ID del departamento al que quiere eliminar\n\n-'))
            rs = self.daod.comprobarEstadoDep(id)
            if rs is not None:
                print(f'{eminem()}\neri wn?')
                system('pause')
                self.__MenuDepA()
            else:
                self.daod.eliminarDep(id)
                rs = self.daod.depEliminadoefectivamente(id)
                print('efectivamente, esta eliminado de la vida\n\n')
                print(rs)
                system('pause')
        except Exception as e:
            print(fu(), e)
            system('pause')
    
    ##_____________________________ESTADISTICAS DEPARTAMENTOS
    
    def __EstadisticasDep(self):
        try:
            rs  = self.daod.estadisticasDep()
            rs2 = self.daod.estadisticasDepHabilitados()
            rs3 = self.daod.Empleados_por_Departamentos()
            rs4 = self.daod.listarDepHab()
            if len(rs) is None:
                system("cls")
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Estadisticas de Departamentos]')
                print("\n\n====NO EXISTEN DATOS PO REY====\n\n")
                system("pause")
            else:
                system("cls")
                print('╔══╗\n╚╗╔╝\n╔╝(¯`v´¯)\n╚══`.¸.[Estadisticas de Departamentos]\n')
                print(f'Cantidad de departamentos    :  {rs[0]}')
                print(f'Departamentos Habilitados    :  {rs2[0]}\n')
                nm = 1
                for x in rs4:
                    print(f'Departamento n°{nm}')
                    print(f'ID      :{x[0]}')
                    print(f'Nombre  :{x[1]}')
                    print(f'Estado  :{x[2]}\n')
                    nm +=1
                print('Cantidad de Empleados por Departamentos:')
                print(f"{'Nombre':<20} | {'Empleados':<6}")
                print("-" * 32)
                for x in rs3:
                    print(f"{x[0]:<20} | {x[1]:<6}")
                print("-" * 27)
                system("pause")
        except Exception as e:
            print(fu(), e)
            system('pause')
    
    #______________________________________________________________SALIR
    
    def __Salir(self):
        system('cls')
        os._exit(1)


