class Persona:
    __id_per = 0
    __rut = 0
    __nom_per = ""
    __apep_per = ""
    __apem_per = ""
    __dir_per = ""
    __tel_per = 0
    
    def __init__(self,
    id_per = 0,
    rut_per = 0,
    nom_per = "",
    apep_per = "",
    apem_per = "",
    dir_per = "",
    tel_per = 0):
        self.__id_per = id_per
        self.__rut = rut_per
        self.__nom_per = nom_per
        self.__apep_per = apep_per
        self.__apem_per = apem_per
        self.__dir_per = dir_per
        self.__tel_per = tel_per
    
    def getIdPer(self):
        return self.__id_per
    
    def setIdPer(self, id):
        self.__id_per = id
    
    def getRut(self):
        return self.__rut
    
    def setRut(self, rut):
        self.__rut = rut
    
    def getNombre(self):
        return self.__nom_per
    
    def setNombre(self, nomp):
        self.__nom_per = nomp
    
    def getApellidoP(self):
        return self.__apep_per
    
    def setApellidoP(self, apep):
        self.__apep_per = apep
    
    def getApellidoM(self):
        return self.__apem_per
    
    def setApellidoM(self, apem):
        self.__apem_per = apem
    
    def getDireccion(self):
        return self.__dir_per
    
    def setDireccion(self, dir):
        self.__dir_per = dir
    
    def getNroTelefono(self):
        return self.__tel_per
    
    def setNroTelefono(self, Nte):
        self.__tel_per = Nte