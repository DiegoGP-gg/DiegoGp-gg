from empleados import Empleados

class Usuario():
    __id_usu = 0
    __id_emp = 0
    __nom_usu = ''
    __corr_usu = ''
    __cont_usu = ''
    
    def __init__(self,
    id_usu = 0 ,
    id_emp = 0 ,
    nom_usu = '' ,
    corr_usu = '' ,
    cont_usu = ''):
        self.__id_usu = id_usu
        self.__id_emp = id_emp
        self.__nom_usu = nom_usu
        self.__corr_usu = corr_usu
        self.__cont_usu = cont_usu
    
    def getIdUsu(self):
        return self.__id_usu
    
    def setIdUsu(self, id):
        self.__id_usu = id
    
    def getIdEmp(self):
        return self.__id_emp
    
    def setIdEmp(self, ide):
        self.__id_emp = ide
    
    def getNomUsu(self):
        return self.__nom_usu
    
    def setNomUsu(self, nom):
        self.__nom_usu = nom
    
    def getCorrUsu(self):
        return self.__corr_usu
    
    def setCorrUsu(self, cor):
        self.__corr_usu = cor
    
    def getContraUsu(self):
        return self.__cont_usu
    
    def setContraUsu(self, con):
        self.__cont_usu = con