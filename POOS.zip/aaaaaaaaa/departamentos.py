from empleados import Empleados

class Departamentos:
    __id_dep = 0
    __nom_dep = ""
    __fman_dep = ""
    __id_est = 0
    __est_est = ""
    
    def __init__(self, id_dep=0, nom_dep="", fman_dep="", id_est=0, est_est = ""):
        self.__id_dep = id_dep
        self.__nom_dep = nom_dep
        self.__fman_dep = fman_dep
        self.__id_est = id_est
        self.__est_est = est_est
    
    def getIdDep(self):
        return self.__id_dep
    
    def setIdDep(self, Idd):
        self.__id_dep = Idd
    
    def getIdEst(self):
        return self.__id_est
    
    def setIdEst(self, Ide):
        self.__id_est = Ide
    
    def getNombreDep(self):
        return self.__nom_dep
    
    def setNombreDep(self, nomd):
        self.__nom_dep = nomd
    
    def getFechaMando(self):
        return self.__fman_dep
    
    def setFechaMando(self, FecM):
        self.__fman_dep = FecM
    
    def getEstEst(self):
        return self.__est_est
    
    def setEstEst(self, est):
        self.__est_est = est