from empleados import Empleados
from departamentos import Departamentos
from Persona import Persona
from os import system
from emine import shrek
import pymysql

class dao:
    em = Empleados()
    pe = Persona()
    def __init__(self):
        pass
    
    def conectar(self):
        self.con = pymysql.connect(
            host = "localhost",
            user = "root",
            password = "",
            db = "proyecto_dep"
        )
        self.cursor = self.con.cursor()
    
    def desconectar(self):
        self.con.close()

    ##_____________________________CREAR EMPLEADOS Y PERSONAS ------------------ listo
    def crearPersona(self, pe):
        sql = """
        INSERT INTO personas
            (rut_per, nom_per, apep_per, apem_per, dir_per, tel_per)
        VALUES
            (%s, %s, %s, %s, %s, %s)
        """
        vals = (
            pe.getRut(),
            pe.getNombre(),
            pe.getApellidoP(),
            pe.getApellidoM(),
            pe.getDireccion(),
            pe.getNroTelefono()
        )
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql, vals)
            new_id = cur.lastrowid
            self.con.commit()
            return new_id
        except Exception as e:
            try:
                self.con.rollback()
            except Exception:
                pass
            print(f"{shrek()}\n--- Error Al Agregar persona (DAO)!! ---\n{e}\n")
            system("pause")
            return None
        finally:
            self.desconectar()
    
    def crearEmpleado(self, em):
        sql = "insert into empleados (id_per, fec_emp, sal_emp, id_est, id_dep) values (%s, %s, %s, 1, %s);"
        vals = (em.getIdPer(), em.getFechaContrato(), em.getSalario(), em.getIdDep())
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql, vals)
            self.con.commit()
        except Exception as e:
            try:
                self.con.rollback()
            except Exception:
                pass
            print(f"{shrek()}\n--- Error Al Agregar empleado (DAO)!! ---\n{e}\n")
            system("pause")
            return None
        finally:
            self.desconectar()

    ##_____________________________LISTAR EMPLEADOS ---------------------------- listo
    def obtenerNombresEmp(self):
        try:
            sql = """select em.id_emp,
            p.rut_per, p.nom_per, p.apep_per, p.apem_per, p.dir_per, p.tel_per,
            em.fec_emp, em.sal_emp,
            es.est_est,
            d.nom_dep
            from empleados em 
            inner join personas p on p.id_per=em.id_per 
            inner join estado es on es.id_est=em.id_est
            inner join departamentos d on d.id_dep=em.id_dep
            order by em.id_emp;"""
            self.conectar()
            self.cursor.execute(sql)
            rs = self.cursor.fetchall()
            self.desconectar()
            return rs
        except:
            print(f"{shrek()}\n--- Error Al Obtener Editoriales (DAO)!! ---", end="\n\n")
            system("pause")
    
    ##_____________________________BUSCAR EMPLEADOS ---------------------------- listo
    def comprobarNombreEmp(self, nom):
        try:
            sql = """select e.id_emp, p.nom_per, p.apep_per, e.fec_emp, e.sal_emp, es.est_est, d.nom_dep
            from empleados e
            inner join personas p on p.id_per=e.id_per
            inner join estado es on es.id_est=e.id_est
            inner join departamentos d on d.id_dep=e.id_dep
            where lower(nom_per)=lower(%s);"""
            self.conectar()
            self.cursor.execute(sql, nom)
            rs = self.cursor.fetchone()
            self.desconectar()
            return rs
        except:
            print(f"{shrek()}\n--- Error Al Comprobar Nombre De Empleado!! (DAO) ---", end="\n\n")
            system("pause")

    ##_____________________________MODIFICAR EMPLEADOS ------------------------- listo
    def obtenerNombresEmp2(self):
        try:
            sql = """select em.id_emp, p.nom_per, p.apep_per, em.sal_emp, es.est_est
            from empleados em 
            inner join personas p on p.id_per=em.id_per 
            inner join estado es on es.id_est=em.id_est
            order by em.id_emp;"""
            self.conectar()
            self.cursor.execute(sql)
            rs = self.cursor.fetchall()
            self.desconectar()
            return rs
        except:
            print(f"{shrek()}\n--- Error Al Obtener Editoriales (DAO)!! ---", end="\n\n")
            system("pause")
    
    def actualizarEmpleado(self, dato, nuevo, id):
        try:
            if dato == 1:
                sql = """update empleados set sal_emp=%s where id_emp=%s;"""
            elif dato == 2:
                sql = """update empleados set id_est=%s where id_emp=%s;"""
            self.conectar()
            vals = (nuevo, id)
            self.cursor.execute(sql, vals)
            self.con.commit()
        except Exception as e:
            print(f"{shrek()}\n--- Error Al Actualizar datos De Empleado!! (DAO) ---{e}\n\n")
            system("pause")
        finally:
            self.desconectar()
    
    def obtenerEstadoEmpleado(self, id_emp):
        self.conectar()
        try:
            self.cursor.execute("SELECT id_est FROM empleados WHERE id_emp=%s", (id_emp,))
            row = self.cursor.fetchone()
            return row[0] if row else None
        finally:
            self.desconectar()
    
    def comprobarDatosEmp(self, id):
        try:
            sql = """select e.id_emp, p.nom_per, p.apep_per, e.sal_emp, es.est_est
            from empleados e
            inner join personas p on p.id_per=e.id_per
            inner join estado es on es.id_est=e.id_est
            where id_emp=%s;"""
            self.conectar()
            self.cursor.execute(sql, id)
            rs = self.cursor.fetchone()
            self.desconectar()
            return rs
        except:
            print(f"{shrek()}\n--- Error Al Comprobar Nombre De Empleado!! (DAO) ---", end="\n\n")
            system("pause")

    ##_____________________________ELIMINAR EMPLEADOS -------------------------- listo
    def listarNombresEmp(self):
        try:
            sql = """select em.id_emp, p.nom_per, p.apep_per, es.est_est
            from empleados em
            inner join personas p on p.id_per=em.id_per
            inner join estado es on es.id_est=em.id_est
            order by em.id_emp;"""
            self.conectar()
            self.cursor.execute(sql)
            rs = self.cursor.fetchall()
            return rs
        except Exception as e:
            print(f"{shrek()}\n--- Error Al Obtener listado de empleados (listarNombresEmp) (DAO)!! ---\n{e}\n")
            system("pause")
        finally:
            self.desconectar()
    
    def eliminarEmpleado(self, op):
        try:
            sql = """update empleados set id_est=2 where id_emp=%s"""
            self.conectar()
            self.cursor.execute(sql, op)
            self.con.commit()
        except Exception as e:
            print(f'error dao\n{e}')
            system('pause')
        finally:
            self.desconectar()
    
    def comprobarEstadoEmp(self, op):
        try:
            sql = """select em.id_emp, p.nom_per, p.apep_per, es.est_est
            from empleados em
            inner join personas p on p.id_per=em.id_per
            inner join estado es on es.id_est=em.id_est
            where id_emp=%s"""
            self.conectar()
            self.cursor.execute(sql, op)
            rs = self.cursor.fetchone()
            return rs
        except Exception as e:
            print(f"{shrek()}\n{e}")
            system('pause')
        finally:
            self.desconectar()
    
    ##_____________________________ESTADISTICAS EMPLEADOS ---------------------- listo
    def estadisticasNombresEmp(self):
        sql = """select count(e.id_emp), avg(e.sal_emp), sum(e.sal_emp)
        from empleados e"""
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql)
            rs2 = cur.fetchone()
            return rs2
        except Exception as e:
            print(f"{shrek()}\n{e}")
            system('pause')
        finally:
            self.desconectar()
    
    def estadisticasEmpHabilitados(self):
        sql = """select count(e.id_emp), avg(e.sal_emp), sum(e.sal_emp)
        from empleados e
        where e.id_est=1"""
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql)
            rs = cur.fetchone()
            return rs
        except Exception as e:
            print(f"{shrek()}\n{e}")
            system('pause')
        finally:
            self.desconectar()