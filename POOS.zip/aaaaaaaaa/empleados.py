from Persona import Persona

class Empleados:
    __id_emp = 0 
    __fec_emp = ""
    __sal_emp = 0
    __id_est = 0
    __id_dep = 0
    __id_per = 0
    __id_rol = 0
    
    def __init__(self,
    id_emp = 0,
    fec_emp = "",
    sal_emp = 0,
    id_est = 0,
    id_dep = 0,
    id_per = 0,
    id_rol = 0):
        self.__id_emp = id_emp
        self.__fec_emp = fec_emp
        self.__sal_emp = sal_emp
        self.__id_est = id_est
        self.__id_dep = id_dep
        self.__id_per = id_per
        self.__id_rol = id_rol
    
    def getIdEmp(self):
        return self.__id_emp
    
    def setIdEmp(self, id):
        self.__id_emp = id
    
    def getFechaContrato(self):
        return self.__fec_emp
    
    def setFechaContrato(self, fcon):
        self.__fec_emp = fcon
    
    def getSalario(self):
        return self.__sal_emp
    
    def setSalario(self, sal):
        self.__sal_emp = sal
    
    def getIdEst(self):
        return self.__id_est
    
    def setIdEst(self, Ide):
        self.__id_est = Ide
    
    def getIdDep(self):
        return self.__id_dep
    
    def setIdDep(self, Idd):
        self.__id_dep = Idd
    
    def getIdPer(self):
        return self.__id_per
    
    def setIdPer(self, Idp):
        self.__id_per = Idp
    
    def getIdRol(self):
        return self.__id_rol
    
    def setIdRol(self, rol):
        self.__id_rol = rol