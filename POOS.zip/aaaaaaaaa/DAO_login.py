from Usuarios import Usuario
from empleados import Empleados
from cryptography.fernet import Fernet
from os import system
from emine import Dk
import pymysql

class DaoLog:
    
    def __init__(self):
        pass
    
    def conectar(self):
        self.con = pymysql.connect(
            host = "localhost",
            user = "root",
            password = "",
            db = "proyecto_dep"
        )
        self.cursor = self.con.cursor()
    
    def desconectar(self):
        self.con.close()
    
    def comprobarUsuario(self, usu):
        try:
            sql = """select us.cont_usu, em.id_est, em.id_rol
            from usuarios us 
            inner join empleados em on em.id_emp=us.id_emp
            where us.nom_usu = %s"""
            self.conectar()
            val = (usu)
            cur = self.cursor
            cur.execute(sql, val)
            aa = cur.fetchone()
            if aa is None:
                return None
            else:
                return aa
        except Exception as e:
            print(f'{Dk()}\nERROR DAOL comprobarUsuario\n{e}')
            system('pause')
        finally:
            self.desconectar()
    
    
    
    def recuperarContra(self, con):
        try:
            sql = """select us.*, em.id_est
            from usuarios us 
            join empleados em on em.id_emp=us.id_emp
            where us.corr_usu = %s"""
            self.conectar()
            val = (con)
            cur = self.cursor
            cur.execute(sql, val)
            rs = cur.fetchone()
            if rs is None:
                return None
            else:
                return rs
        except Exception as e:
            print(f'{Dk()}\nERROR DAOL recuperarContra\n{e}')
            system('pause')
        finally:
            self.desconectar()
    
    def cambiarContra(self, cor, conN):
        sql = """
        UPDATE usuarios
        SET cont_usu = %s
        WHERE corr_usu = %s
    """
        try:
            self.conectar()
            val = (conN, cor)
            cur = self.cursor
            cur.execute(sql, val)
            self.con.commit()
        except Exception as e:
            try:
                self.con.rollback()
            except Exception:
                pass
            print(f'{Dk()}\n error en cambiarContra\n{e}')
            system('pause')
        finally:
            self.desconectar()
    
    