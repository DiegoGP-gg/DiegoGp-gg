from empleados import Empleados
from departamentos import Departamentos
from Persona import Persona
from os import system
import pymysql

from emine import nose

class daoDep:
    de = Departamentos()

    _COLUMNS_EXCLUDED = {"id_dep"}
    _columns_cache = None
    _columns_cache_fmi_estados = None
    _LABELS_COLUMNS = {
        "nom_dep":  "Nombre del departamento",
        "fman_dep": "Fecha de mando",
        "id_est":   "Estado"
    }
    
    def __init__(self):
        pass
    
    def conectar(self):
        self.con = pymysql.connect(
            host = "localhost",
            user = "root",
            password = "",
            db = "proyecto_dep"
        )
        self.cursor = self.con.cursor()
    
    def desconectar(self):
        self.con.close()
    
    ##_____________________________Crear Departamentos ---------------------------- listo
    
    def comprobarNombresDep(self, nomd):
        try:
            sql = """select de.nom_dep
            from departamentos de
            where lower(de.nom_dep) like lower(%s)"""
            self.conectar()
            cur = self.cursor
            cur.execute(sql, nomd)
            rs = cur.fetchone()
            return rs
        except Exception as e:
            print(f'{nose()}\nerror manito en comprobarnomd dao\n{e}')
            system('pause')
        finally:
            self.desconectar()
    
    def crearDepartamento(self, de):
        sql = """insert into departamentos
        (nom_dep, fman_dep, id_est)
        values (%s, %s, 1);"""
        vals = (
            de.getNombreDep(),
            de.getFechaMando()
        )
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql, vals)
            self.con.commit()
        except Exception as e:
            print(f'{nose()}\nerror manito en creardep dao\n{e}')
            system('pause')
        finally:
            self.desconectar()
    
    ##_____________________________Listar Departamentos --------------------------- listo
    
    def listar_departamentos(self):
        sql = """
            SELECT d.id_dep, d.nom_dep, d.fman_dep, e.id_est, e.est_est
            FROM departamentos as d
            LEFT JOIN estado as e on e.id_est=d.id_est
            ORDER BY d.id_dep ASC;
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql)
            rows = cur.fetchall()
            deps = []
            for (id_dep, nom_dep, fman_dep, id_est, est_est) in rows:
                dep = Departamentos(
                    id_dep=id_dep,
                    nom_dep=nom_dep or "",
                    fman_dep=str(fman_dep) if fman_dep is not None else "",
                    id_est=id_est if id_est is not None else 1,
                    est_est=est_est or ""
                )
                deps.append(dep)
            return deps
        except Exception as e:
            print(f'{nose()}\nerror manito en listardep dao\n{e}')
            system("pause")
            return []
        finally:
            self.desconectar()
    
    def imprimir_departamentos(self, deps):
        print("\n================= LISTA DE DEPARTAMENTOS =================")
        print(f"{'ID':<6} | {'Nombre':<30} | {'FechaMando':<20} | {'Estado':<20}")
        print("-" * 72)
        for d in deps:
            print(f"{str(d.getIdDep()):<6} | {d.getNombreDep().capitalize():<30} | {d.getFechaMando():<20} | {d.getEstEst().capitalize():<20}")
        print("-" * 72)
    
    ##_____________________________Buscar Departamentos --------------------------- listo
    
    def buscarDepExistente(self, id):
        sql = """select d.id_dep, d.nom_dep, d.fman_dep, e.est_est
        from departamentos as d
        inner join estado as e on e.id_est=d.id_est
        where d.id_dep=%s
        order by d.id_dep asc;
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql, id)
            rs = cur.fetchone()
            return rs
        except Exception as e:
            print(nose(), e)
        finally:
            self.desconectar()
    
    def _escape_like(self, s: str) -> str:
        return s.replace('!', '!!').replace('%', '!%').replace('_', '!_')
    
    def buscar_departamentos(self, texto: str):
        texto = (texto or "").strip()
        pattern = "%" + self._escape_like(texto) + "%" if texto else "%"
        sql = """
            SELECT d.id_dep, d.nom_dep, d.fman_dep, e.id_est, e.est_est
            FROM departamentos AS d
            LEFT JOIN estado AS e ON e.id_est=d.id_est
            WHERE d.nom_dep LIKE %s ESCAPE '!'
            ORDER BY d.id_dep ASC
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql, (pattern,))
            rows = cur.fetchall()
            deps = []
            for (id_dep, nom_dep, fman_dep, id_est, est_est) in rows:
                deps.append(Departamentos(
                    id_dep=id_dep,
                    nom_dep=nom_dep or "",
                    fman_dep=str(fman_dep) if fman_dep is not None else "",
                    id_est=id_est if id_est is not None else 0,
                    est_est=est_est or ""
                ))
            return deps
        except Exception as e:
            print(f"{nose()}\n--- Error al buscar departamentos (DAO) ---\n{e}\n")
            system("pause")
            return []
        finally:
            self.desconectar()
    
    def buscar_por_nombre_y_listar_departamentos(self, texto: str):
        deps = self.buscar_departamentos(texto)
        self.imprimir_departamentos(deps)
        return deps
    
    ##_____________________________Modificar Departamentos ------------------------ listo
    
    def listarDepMod(self):
        sql = """
            SELECT d.nom_dep, d.fman_dep, e.est_est
            FROM departamentos as d
            LEFT JOIN estado as e on e.id_est=d.id_est
            ORDER BY d.id_dep ASC;
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql)
            rows = cur.fetchall()
            deps = []
            for (nom_dep, fman_dep, est_est) in rows:
                dep = Departamentos(
                    nom_dep=nom_dep or "",
                    fman_dep=str(fman_dep) if fman_dep is not None else "",
                    est_est=est_est or ""
                )
                deps.append(dep)
            return deps
        except Exception as e:
            print(f'{nose()}\nerror manito en listardep dao\n{e}')
            system("pause")
            return []
        finally:
            self.desconectar()
    
    def imprimir_DepMod(self, deps):
        """
        Imprime en formato tabla simple pero así bien bonita bien sabrosona.
        """
        print("\n================= LISTA DE DEPARTAMENTOS =================")
        print(f"{'Nombre':<30} | {'FechaMando':<20} | {'Estado':<20}")
        print("-" * 72)
        for d in deps:
            print(f"{d.getNombreDep().capitalize():<30} | {d.getFechaMando():<20} | {d.getEstEst().capitalize():<20}")
        print("-" * 72)
    
    ## Lo siguiente es del diablo

# ------------- Funciones editar -------------
    def obtener_departamento_por_id(self, id_dep: int):
        sql = """
        SELECT d.id_dep, d.nom_dep, d.fman_dep, d.id_est, e.est_est
        FROM departamentos d
        LEFT JOIN estado e ON e.id_est = d.id_est
        WHERE d.id_dep = %s
        LIMIT 1
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql, (id_dep,))
            row = cur.fetchone()
            if not row: return None
            return {
                "id_dep": row[0],
                "nom_dep": row[1],
                "fman_dep": row[2],
                "id_est": row[3],
                "est_est": row[4],
            }
        finally:
            self.desconectar()

# --- Obtiene columnas reales de la tabla, en el orden físico (ORDINAL_POSITION)
    def _get_table_columns(self, force_refresh=False):
        if self._columns_cache is not None and not force_refresh:
            return self._columns_cache
        
        sql = """
            SELECT COLUMN_NAME
            FROM information_schema.COLUMNS
            WHERE
                TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = 'departamentos'
            ORDER BY ORDINAL_POSITION
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql)
            cols = [row[0] for row in cur.fetchall()]
            self._columns_cache = cols
            return cols
        except Exception as e:
            print(f"{nose()}\n--- Error leyendo columnas de departamentos ---\n{e}\n")
            system("pause")
            return []
        finally:
            self.desconectar()

    def get_editable_columns(self):
        """
        Devuelve lista de columnas editables (excluye las de _COLUMNS_EXCLUDED).
        """
        cols = self._get_table_columns()
        return [c for c in cols if c not in self._COLUMNS_EXCLUDED]

    def imprimir_columnas_editables(self):
        """
        Imprime columnas editables con índice 1..N según el orden mostrado.
        """
        cols = self.get_editable_columns()
        labels = getattr(self, "_LABELS_COLUMNS", {}) or {}
        print("\n===== Columnas editables (elige por índice) =====")
        for i, col in enumerate(cols, start=1) :
            label = labels.get(col, col)
            print(f"{i}. {label}")
        print("0. Cancelar y volver a elegir departamento")
        return cols

# --- Mostras mas info sobre una columna (si aplica) y retornar variables de distinto tipos
    def mostrar_mas_info_valor_columna(self, col):
        if col == "id_est":
            if self._columns_cache_fmi_estados is not None:
                return self._columns_cache_fmi_estados
            # Consulta posibles valores para id_est
            sql = "SELECT id_est, est_est FROM estado ORDER BY id_est ASC"
            self.conectar()
            try:
                cur = self.cursor
                cur.execute(sql)
                rows = cur.fetchall()
                opciones = {int(r[0]) for r in rows}
                print("\nValores válidos para 'id_est':")
                for r in rows:
                    print(f"{r[0]} - {str(r[1]).capitalize()}")
                self._columns_cache_fmi_estados = opciones
                return opciones
            finally:
                self.desconectar()
        return None  # valor por defecto si no hay info extra

    def validar_valor_columna(self, col, valor_str, val_mas_info=None):
        """
        Valida y transforma el valor según columna.
        Devuelve (ok: bool, valor_transformado | mensaje_error)
        """
        s = (valor_str or "").strip()

        if col == "nom_dep":
            if 1 <= len(s) <= 100:
                return True, s
            return False, "Nombre vacío o muy largo (1-100)."
        elif col == "fman_dep":
            # Fecha esperada 'DD-MM-YYYY' (ajusta si maneja datetime)
            try:
                dt =self.datetime.strptime(s, "%d-%m-%Y")
                # Puedes retornar string o dt según cómo guardes en DB:
                return True, dt.strftime("%Y-%m-%d")
            except Exception:
                return False, "Formato de fecha inválido. Use DD-MM-YYYY."
        elif col == "id_est":
            # Espera 1 o 2 (Habilitado/Deshabilitado)
            if val_mas_info and isinstance(val_mas_info, set):
                if s.isdigit():
                    v = int(s)
                    if v in val_mas_info:
                        return True, v
                    else: return False, f"Valor inválido. Use uno de: {', '.join(map(str, val_mas_info))}."
                else:
                    return False, "Debe ingresar un número entero."
            return False, "Error interno validando 'id_est'."

        else:
            # default: sin validación especial
            return True, s

# ------------- update parcial -------------
    def update_departamento_parcial(self, id_dep: int, data: dict):
        if not data:
            print("\n(No hay cambios que aplicar)\n")
            return 0

        # Seguridad: solo columnas realmente editables
        editables = set(self.get_editable_columns())
        data = {k: v for k, v in data.items() if k in editables}
        if not data:
            print("\n(No quedaron columnas válidas para actualizar)\n")
            return 0

        set_parts = [f"{col}=%s" for col in data.keys()]
        values = list(data.values()) + [id_dep]

        sql = """
            UPDATE departamentos
            SET {sets}
            WHERE id_dep=%s
        """.format(sets=", ".join(set_parts))

        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql, tuple(values))
            self.con.commit()
            return cur.rowcount
        except Exception as e:
            try: self.con.rollback()
            except Exception: pass
            print(f"{nose()}\n--- Error al actualizar departamento (DAO) ---\n{e}\n")
            system("pause")
            return 0
        finally:
            self.desconectar()

    ## Aqui el diablo dejó de estar por aqui
    
    ##_____________________________Eliminar Departamentos ------------------------- listo
    
    def listarDepDel(self):
        sql = """
            SELECT d.id_dep, d.nom_dep, e.est_est
            FROM departamentos as d
            INNER JOIN estado as e on e.id_est=d.id_est
            ORDER BY d.id_dep ASC;
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql)
            rows = cur.fetchall()
            deps = []
            for (id_dep, nom_dep, est_est) in rows:
                dep = Departamentos(
                    id_dep=id_dep,
                    nom_dep=nom_dep or "",
                    est_est=est_est or ""
                )
                deps.append(dep)
            return deps
        except Exception as e:
            print(f'{nose()}\nerror manito en listardep dao\n{e}')
            system("pause")
            return []
        finally:
            self.desconectar()
    
    def imprimir_DepDel(self, deps):
        print("\n================= LISTA DE DEPARTAMENTOS =================")
        print(f"{'ID':<6} | {'Nombre':<30} | {'Estado':<20}")
        print("-" * 72)
        for d in deps:
            print(f"{str(d.getIdDep()):<6} | {d.getNombreDep().capitalize():<30} | {d.getEstEst().capitalize():<20}")
        print("-" * 72)
    
    def comprobarEstadoDep(self, id):
        sql = """select d.id_dep
        from departamentos as d
        where id_dep=%s and d.id_est=2
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql, id)
            rs = cur.fetchone()
            return rs
        except Exception as e:
            print(nose(), e)
            system('pause')
        finally:
            self.desconectar()
    
    def eliminarDep(self, id):
        sql = """update departamentos
        set id_est=2 where id_dep=%s
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql, id)
            self.con.commit()
        except Exception as e:
            print(nose(), e)
            system('pause')
        finally:
            self.desconectar()
    
    def depEliminadoefectivamente(self, id):
        sql = """
            SELECT d.id_dep, d.nom_dep, e.est_est
            FROM departamentos as d
            INNER JOIN estado as e on e.id_est=d.id_est
            where d.id_dep=%s
            ORDER BY d.id_dep ASC;
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql, id)
            rs = cur.fetchone()
            return rs
        except Exception as e:
            print(nose(), e)
            system('pause')
        finally:
            self.desconectar()
    
    ##_____________________________Estadisticas Departamentos --------------------- listo
    
    def estadisticasDep(self):
        sql = """select count(d.id_dep)
        from departamentos d"""
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql)
            rs2 = cur.fetchone()
            return rs2
        except Exception as e:
            print(nose(), e)
            system('pause')
        finally:
            self.desconectar()
    
    def estadisticasDepHabilitados(self):
        sql = """select count(d.id_dep)
        from departamentos d
        where d.id_est=1"""
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql)
            rs = cur.fetchone()
            return rs
        except Exception as e:
            print(nose(), e)
            system('pause')
        finally:
            self.desconectar()
    
    def Empleados_por_Departamentos(self):
        sql = """select d.nom_dep, count(e.id_emp)
        from empleados e
        inner join departamentos d on d.id_dep=e.id_dep
        group by d.nom_dep
        order by d.id_dep;"""
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql)
            rs = cur.fetchall()
            return rs
        except Exception as e:
            print(nose(), e)
            system('pause')
        finally:
            self.desconectar()
    
    def listarDepHab(self):
        sql = """
            SELECT d.id_dep, d.nom_dep, e.est_est
            FROM departamentos as d
            INNER JOIN estado as e on e.id_est=d.id_est
            WHERE d.id_est=1
            ORDER BY d.id_dep ASC;
        """
        self.conectar()
        try:
            cur = self.cursor
            cur.execute(sql)
            deps = cur.fetchall()
            return deps
        except Exception as e:
            print(f'{nose()}\nerror manito en listardep dao\n{e}')
            system("pause")
            return []
        finally:
            self.desconectar()
    