from Sistema import sistema
from DAO import dao

class principal:
    __s = sistema()
    
    def ejecutarPrograma(self):
        self.__s.Menuini()

p = principal()
p.ejecutarPrograma()

#Juan.Perez        - activo    - a123       -1 -admin
#Martina.Sepulveda - desactivo - e123       -2 -demas
#Jose.Gomez        - activo    - b123       -3 -demas
#Nicolas.Balmaseda - desactivo - f123       -4 -demas
#Jorge.Lopez       - activo    - c123       -5 -admin
#Contanza.Traverso - descativo - g123       -6 -demas
#Rogelio.Cuadrado  - activo    - d123       -7 -demas
#Alexander.Gomez   - descativo - h123       -8 -demas